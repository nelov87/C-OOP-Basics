﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Food
{
    public abstract class Food
    {
        public int Happiness { get; protected set; }
    }
}
