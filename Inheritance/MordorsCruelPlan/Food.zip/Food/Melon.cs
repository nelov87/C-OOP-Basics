﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Food
{
    public class Melon : Food
    {
        public Melon()
        {
            this.Happiness = 1;
        }
    }
}
