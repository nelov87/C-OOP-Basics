﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Food
{
    public class Lembas : Food
    {
        public Lembas()
        {
            this.Happiness = 3;
        }
    }
}
