﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Food
{
    public class Cram : Food
    {
        public Cram()
        {
            this.Happiness = 2;
        }
    }
}
