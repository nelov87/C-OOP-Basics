﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Food
{
    public class HoneyCake : Food
    {
        public HoneyCake()
        {
            this.Happiness = 5;
        }
    }
}
