﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Food
{
    public class Mushrooms : Food
    {
        public Mushrooms()
        {
            this.Happiness = -10;
        }
    }
}
