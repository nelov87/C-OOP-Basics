﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Food
{
    public class Else : Food
    {
        public Else()
        {
            this.Happiness = -1;
        }
    }
}
