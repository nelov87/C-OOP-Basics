﻿using P08_MilitaryElite.Core;
using System;

namespace P08_MilitaryElite
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
