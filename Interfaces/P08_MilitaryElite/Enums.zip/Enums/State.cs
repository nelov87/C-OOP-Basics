﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P08_MilitaryElite.Enums
{
    public enum State
    {
        inProgress = 1,
        Finished = 2
    }
}
