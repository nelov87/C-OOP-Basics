﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06_BirthdayCelebrations
{
    interface IBurthable
    {
        
        string BurthDate { get; set; }
    }
}
