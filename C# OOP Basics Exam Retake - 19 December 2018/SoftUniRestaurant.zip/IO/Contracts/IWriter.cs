﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftUniRestaurant.IO.Contracts
{
    public interface IWriter
    {
        void Write(string str);
    }
}
