﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftUniRestaurant.IO.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
