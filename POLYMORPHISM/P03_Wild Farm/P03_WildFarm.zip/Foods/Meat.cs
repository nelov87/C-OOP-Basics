﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_Wild_Farm.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
