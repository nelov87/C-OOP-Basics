﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_Wild_Farm.Foods
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
