﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_Wild_Farm.Animals
{
    public interface IFeline
    {
        string Breed { get; }
    }
}
