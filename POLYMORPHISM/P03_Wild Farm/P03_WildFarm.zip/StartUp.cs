﻿using P03_Wild_Farm.Core;
using System;

namespace P03_Wild_Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
