﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Interfaces
{
    public interface IGpu
    {

    }
}
